<!DOCTYPE html>
<html>
<head>
	<title>Gold Loan Management System</title>
	<style type="text/css">
		.main1{
			width: 100%;
		}
		.sub1{
			width: 70%;
			margin: auto;
		}
		.footer{
			height: 50px;
			background-color: #580000;
			width: 100%;
			text-align: center;
			color: white;
			line-height: 50px;
		}
		b{
			font-size: 30px;
		}
		@keyframes footer{
		0%{color: #0000FF;}
		17%{color: #00FF00;}
		34%{color: #FFFF00;}
		51%{color: #FF7F00;}
		68%{color: #FF0000;}
		85%{color: #9400D3;}
		100%{color: #4B0082;}
		}
		i{
			font-family: Comic Sans MS;
			animation: footer 5s infinite;
		}
	</style>
</head>
<body>

	<div class="main1 footer">
        <div class="sub1 ">
             Copyright@ 2017 Gold management System Created with html5, css3, php, mysql.
        </div>
    </div>
    <div class="main1 footer">
        <div class="sub1 ">
             <b>Created By :- <i>Your name</i></b> 
        </div>
    </div>

</body>
</html>