<!DOCTYPE html>
<html>
<head>
	<title>Admin Section - Gold Loan Management System</title>
</head>

<frameset cols="50%,50%">
	  	<frame src="emp_data.php">
	  	<frame src="cust_data.php">
</frameset>
</html>