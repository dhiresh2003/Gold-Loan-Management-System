
Hello, My Name is Manish Kini.

This project is simple project, which i created with HTML, CSS, PHP, MySQL

Models : 1. Employee 
              2. Customer 
              3. Admin.
Functionality : 
              Employee can check his details, customer can take loan and can pay interest on his loan, Admin can set                the loan amount aspar the carat's and can also able to see the customer details, Admin can add or                         remove employee from his database.
YouTube link : 
              https://www.youtube.com/watch?v=-OHOrbadEAA# GoldLoanManagementSystem
